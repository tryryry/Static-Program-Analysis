/*
 * Tai-e: A Static Analysis Framework for Java
 *
 * Copyright (C) 2020-- Tian Tan <tiantan@nju.edu.cn>
 * Copyright (C) 2020-- Yue Li <yueli@nju.edu.cn>
 * All rights reserved.
 *
 * Tai-e is only for educational and academic purposes,
 * and any form of commercial use is disallowed.
 * Distribution of Tai-e is disallowed without the approval.
 */

package pascal.taie.analysis.pta.cs;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import pascal.taie.World;
import pascal.taie.analysis.graph.callgraph.CallGraphs;
import pascal.taie.analysis.graph.callgraph.CallKind;
import pascal.taie.analysis.graph.callgraph.Edge;
import pascal.taie.analysis.pta.PointerAnalysisResult;
import pascal.taie.analysis.pta.PointerAnalysisResultImpl;
import pascal.taie.analysis.pta.core.cs.CSCallGraph;
import pascal.taie.analysis.pta.core.cs.context.Context;
import pascal.taie.analysis.pta.core.cs.element.ArrayIndex;
import pascal.taie.analysis.pta.core.cs.element.CSCallSite;
import pascal.taie.analysis.pta.core.cs.element.CSManager;
import pascal.taie.analysis.pta.core.cs.element.CSMethod;
import pascal.taie.analysis.pta.core.cs.element.CSObj;
import pascal.taie.analysis.pta.core.cs.element.CSVar;
import pascal.taie.analysis.pta.core.cs.element.InstanceField;
import pascal.taie.analysis.pta.core.cs.element.MapBasedCSManager;
import pascal.taie.analysis.pta.core.cs.element.Pointer;
import pascal.taie.analysis.pta.core.cs.element.StaticField;
import pascal.taie.analysis.pta.core.cs.selector.ContextSelector;
import pascal.taie.analysis.pta.core.heap.HeapModel;
import pascal.taie.analysis.pta.core.heap.Obj;
import pascal.taie.analysis.pta.plugin.taint.TaintAnalysiss;
import pascal.taie.analysis.pta.pts.PointsToSet;
import pascal.taie.analysis.pta.pts.PointsToSetFactory;
import pascal.taie.config.AnalysisOptions;
import pascal.taie.ir.exp.InvokeExp;
import pascal.taie.ir.exp.Var;
import pascal.taie.ir.stmt.*;
import pascal.taie.language.classes.JField;
import pascal.taie.language.classes.JMethod;
import pascal.taie.language.type.Type;

import java.util.List;

public class Solver {

    private static final Logger logger = LogManager.getLogger(Solver.class);

    private final AnalysisOptions options;

    private final HeapModel heapModel;

    private final ContextSelector contextSelector;

    private CSManager csManager;

    private CSCallGraph callGraph;

    private PointerFlowGraph pointerFlowGraph;

    private WorkList workList;

    private TaintAnalysiss taintAnalysis;

    private PointerAnalysisResult result;

    Solver(AnalysisOptions options, HeapModel heapModel,
           ContextSelector contextSelector) {
        this.options = options;
        this.heapModel = heapModel;
        this.contextSelector = contextSelector;
    }

    public AnalysisOptions getOptions() {
        return options;
    }

    public ContextSelector getContextSelector() {
        return contextSelector;
    }

    public CSManager getCSManager() {
        return csManager;
    }

    void solve() {
        initialize();
        analyze();
        taintAnalysis.onFinish();
    }

    private void initialize() {
        csManager = new MapBasedCSManager();
        callGraph = new CSCallGraph(csManager);
        pointerFlowGraph = new PointerFlowGraph();
        workList = new WorkList();
        taintAnalysis = new TaintAnalysiss(this);
        // process program entry, i.e., main method
        Context defContext = contextSelector.getEmptyContext();
        JMethod main = World.getMainMethod();
        CSMethod csMethod = csManager.getCSMethod(defContext, main);
        callGraph.addEntryMethod(csMethod);
        addReachable(csMethod);
    }

    public void TaintSolver(CSVar csVar,CSObj csObj){
        PointsToSet pointsToSet=PointsToSetFactory.make(csObj);
        workList.addEntry(csVar,pointsToSet);
    }
    public void TaintAddPFG(CSVar src,CSVar dst){
        addPFGEdge(src,dst);
    }


    /**
     * Processes new reachable context-sensitive method.
     */
    private void addReachable(CSMethod csMethod) {
        // TODO - finish me
        StmtProcessor stmtProcessor=new StmtProcessor(csMethod);
        if(callGraph.addReachableMethod(csMethod)){
            for(Stmt stmt:csMethod.getMethod().getIR().getStmts()){
                stmt.accept(stmtProcessor);
            }
        }
    }

    /**
     * Processes the statements in context-sensitive new reachable methods.
     */
    private class StmtProcessor implements StmtVisitor<Void> {

        private final CSMethod csMethod;

        private final Context context;

        private StmtProcessor(CSMethod csMethod) {
            this.csMethod = csMethod;
            this.context = csMethod.getContext();
        }
        public Void visit(New stmt) {
            Context heapContext=contextSelector.selectHeapContext(csMethod,heapModel.getObj(stmt));

            CSVar csVar=csManager.getCSVar(context, stmt.getLValue());
            CSObj csObj=csManager.getCSObj(heapContext,heapModel.getObj(stmt));

            workList.addEntry(csVar, PointsToSetFactory.make(csObj));
            return null;
        }
        public Void visit(Copy stmt){
            CSVar csVarLeft=csManager.getCSVar(context,stmt.getLValue());
            CSVar csVarRight=csManager.getCSVar(context,stmt.getRValue());
            addPFGEdge(csVarRight,csVarLeft);
            return null;
        }
        public Void  visit(LoadField stmt) {
            if(stmt.isStatic()){
                CSVar csVar=csManager.getCSVar(context,stmt.getLValue());
                StaticField staticField= csManager.getStaticField(stmt.getFieldRef().resolve());
                addPFGEdge(staticField,csVar);
            }
            return null;
        }
        public Void  visit(StoreField stmt) {
            if(stmt.isStatic()){
                CSVar csVar=csManager.getCSVar(context,stmt.getRValue());
                StaticField staticField=csManager.getStaticField(stmt.getFieldRef().resolve());
                addPFGEdge(csVar,staticField);
            }
            return null;
        }
        public Void  visit(Invoke stmt) {
            if(stmt.isStatic()){

                JMethod jMethod=resolveCallee(null,stmt);

                CSCallSite csCallSite=csManager.getCSCallSite(context,stmt);
                Context staticContext=contextSelector.selectContext(csCallSite,jMethod);
                CSMethod csMethod=csManager.getCSMethod(staticContext,jMethod);
                if(callGraph.addEdge(new Edge<CSCallSite, CSMethod>(CallKind.STATIC,csCallSite,csMethod))){
                    addReachable(csMethod);

                    List<Var> Args=stmt.getRValue().getArgs();
                    List<Var>Params=jMethod.getIR().getParams();
                    for(int i=0;i<Args.size();i++){
                        addPFGEdge(csManager.getCSVar(context,Args.get(i)),csManager.getCSVar(staticContext,Params.get(i)));
                    }

                    for(Var var:jMethod.getIR().getReturnVars()){
                        if(var==null)
                            continue;
                        if(stmt.getLValue()==null)
                            break;
                        addPFGEdge(csManager.getCSVar(staticContext,var),csManager.getCSVar(context,stmt.getLValue()));
                    }
                }
                taintAnalysis.handle(stmt,context,jMethod);
            }
            return null;
        }
        // TODO - if you choose to implement addReachable()
        //  via visitor pattern, then finish me
    }

    /**
     * Adds an edge "source -> target" to the PFG.
     */
    private void addPFGEdge(Pointer source, Pointer target) {
        // TODO - finish me
        if(pointerFlowGraph.addEdge(source,target)){
            if(!source.getPointsToSet().isEmpty()){
                workList.addEntry(target,source.getPointsToSet());
            }
        }
    }

    /**
     * Processes work-list entries until the work-list is empty.
     */
    private void analyze() {
        // TODO - finish me
        while(!workList.isEmpty()){
            WorkList.Entry entry=workList.pollEntry();
            PointsToSet diffPointsToSet=propagate(entry.pointer,entry.pointsToSet);
            if(entry.pointer instanceof CSVar){
                if(!diffPointsToSet.isEmpty()&&diffPointsToSet!=null) {
                    Var var=((CSVar) entry.pointer).getVar();
                    String str=var.toString();
                    Context context=((CSVar) entry.pointer).getContext();
                    for (CSObj obj : diffPointsToSet) {
                        for(StoreField storeField:var.getStoreFields()){
                            CSVar csVar=csManager.getCSVar(context,storeField.getRValue());
                            InstanceField instanceField=csManager.getInstanceField(obj,storeField.getFieldRef().resolve());
                            addPFGEdge(csVar,instanceField);
                        }
                        for(LoadField loadField:var.getLoadFields()){
                            CSVar csVar=csManager.getCSVar(context,loadField.getLValue());
                            InstanceField instanceField=csManager.getInstanceField(obj,loadField.getFieldRef().resolve());
                            addPFGEdge(instanceField,csVar);
                        }
                        for(StoreArray storeArray:var.getStoreArrays()){
                            CSVar csVar=csManager.getCSVar(context,storeArray.getRValue());
                            ArrayIndex arrayIndex=csManager.getArrayIndex(obj);
                            addPFGEdge(csVar,arrayIndex);
                        }
                        for(LoadArray loadArray:var.getLoadArrays()){
                            CSVar csVar=csManager.getCSVar(context,loadArray.getLValue());
                            ArrayIndex arrayIndex=csManager.getArrayIndex(obj);
                            addPFGEdge(arrayIndex,csVar);
                        }
                        if(!taintAnalysis.isTaintObj(obj.getObject()))
                            processCall((CSVar) entry.pointer,obj);


                    }
                }
            }
        }
    }

    /**
     * Propagates pointsToSet to pt(pointer) and its PFG successors,
     * returns the difference set of pointsToSet and pt(pointer).
     */
    private PointsToSet propagate(Pointer pointer, PointsToSet pointsToSet) {
        // TODO - finish me
        PointsToSet diffPointsToSet=PointsToSetFactory.make();
        if(!pointsToSet.isEmpty()){
            for(CSObj obj:pointsToSet){
                if(pointer.getPointsToSet().addObject(obj)){
                    diffPointsToSet.addObject(obj);
                }
            }
            pointerFlowGraph.succsOf(pointer).forEach(succ->{
                workList.addEntry(succ,diffPointsToSet);
            });
        }
        return diffPointsToSet;
        //return null;
    }

    /**
     * Processes instance calls when points-to set of the receiver variable changes.
     *
     * @param recv    the receiver variable
     * @param recvObj set of new discovered objects pointed by the variable.
     */
    private void processCall(CSVar recv, CSObj recvObj) {
        // TODO - finish me
        Context context=recv.getContext();
        for(Invoke invoke:recv.getVar().getInvokes()){
            JMethod jMethod=resolveCallee(recvObj,invoke);
            if(jMethod==null)
                continue;
            assert (jMethod!=null);

            Context invokeContext=contextSelector.selectContext(csManager.getCSCallSite(context,invoke),recvObj,jMethod);

            workList.addEntry(csManager.getCSVar(invokeContext,jMethod.getIR().getThis()),PointsToSetFactory.make(recvObj));
            CallKind kind = null;
            if(invoke.isInterface()){
                kind=CallKind.INTERFACE;
            }else if(invoke.isSpecial()){
                kind=CallKind.SPECIAL;
            }else if(invoke.isDynamic()){
                kind=CallKind.DYNAMIC;
            }else if(invoke.isVirtual()){
                kind=CallKind.VIRTUAL;
            }else{
                kind=CallKind.OTHER;
            }
            if(callGraph.addEdge(new Edge<CSCallSite,CSMethod>(kind,csManager.getCSCallSite(context,invoke),csManager.getCSMethod(invokeContext,jMethod)))){
                addReachable(csManager.getCSMethod(invokeContext,jMethod));
                List<Var>Args=invoke.getRValue().getArgs();
                List<Var>Params=jMethod.getIR().getParams();
                for(int i=0;i<Args.size();i++){
                    addPFGEdge(csManager.getCSVar(context,Args.get(i)),csManager.getCSVar(invokeContext,Params.get(i)));
                }

                for(Var var:jMethod.getIR().getReturnVars()){
                    if(var==null)
                        continue;
                    if(invoke.getLValue()==null)
                        break;
                    addPFGEdge(csManager.getCSVar(invokeContext,var),csManager.getCSVar(context,invoke.getLValue()));
                }
            }
            taintAnalysis.handle(invoke,context,jMethod);
        }
    }

    /**
     * Resolves the callee of a call site with the receiver object.
     *
     * @param recv the receiver object of the method call. If the callSite
     *             is static, this parameter is ignored (i.e., can be null).
     * @param callSite the call site to be resolved.
     * @return the resolved callee.
     */
    private JMethod resolveCallee(CSObj recv, Invoke callSite) {
        Type type = recv != null ? recv.getObject().getType() : null;
        return CallGraphs.resolveCallee(type, callSite);
    }

    public PointerAnalysisResult getResult() {
        if (result == null) {
            result = new PointerAnalysisResultImpl(csManager, callGraph);
        }
        return result;
    }
}
